# nested

zip walker sees paths.
